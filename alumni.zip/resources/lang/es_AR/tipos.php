<?php

return [

    'tipo' => 'Tipo',
    'tipos' => 'Tipos',
    'nombre' => 'Nombre',
    'descripcion' => 'Descripción'


];
