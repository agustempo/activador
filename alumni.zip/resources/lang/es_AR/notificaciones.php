<?php

return [
    'te_inscribiste' => 'Te inscribiste en la actividad',
    'te_desinscribiste' => 'Te desinscribiste en la actividad',
    'accede_a_inscripciones' => 'podés acceder a tus inscripciones',
    'se_inscribio' => '¡Te inscribiste a la actividad!',
    'aca' => 'acá',
    'se_inscribio' => 'se inscribió a la actividad',
    'se_modifico' => 'Se modificó',
    'se_elimino' => 'Se eliminó',
];