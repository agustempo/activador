<?php echo e(__('notificaciones.se_modifico')); ?>

<a href="/actividades/<?php echo e($notificacion->data['id']); ?>"><?php echo e($notificacion->data["nombre"]); ?></a>
<span class="has-text-grey-light" ><?php echo e($notificacion->updated_at->diffForHumans()); ?></span>
<?php /* /home/sugar/TEC/activador/resources/views/notificaciones/ActividadModificada.blade.php */ ?>