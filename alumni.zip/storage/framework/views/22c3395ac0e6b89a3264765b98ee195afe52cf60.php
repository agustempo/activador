<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="columns">
        <div class="column is-4 is-offset-4">
            <div class="box">
                <div class="title is-4"><?php echo e(__('Reset Password')); ?></div>

                <div class="">
                    <?php if(session('status')): ?>
                        <div class="notification is-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="field">
                            <label for="email" class="label"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="control">
                                <input id="email" type="email" class="input<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                            </div>
                        </div>

                        <div class="">
                            <div class="buttons">
                                <button type="submit" class="button is-primary">
                                    <?php echo e(__('passwords.send_password_reset_link')); ?>

                                </button>
                            </div>
                        </div>
                    </form>

                </div>

            </div>

            <?php if($errors->has('email')): ?>
            <div class="notification is-danger" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/auth/passwords/email.blade.php */ ?>