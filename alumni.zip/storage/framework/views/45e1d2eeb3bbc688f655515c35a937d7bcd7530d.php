<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" >
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent("title"); ?></title>
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="/css/activador.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
  </head>
  <body style="display: flex; flex-direction: column; min-height: 100vh;">

    <?php $__env->startSection("navbar"); ?>
    <nav class="navbar is-primary" role="navigation" aria-label="main navigation">
      <div class="container">
        <div class="navbar-brand">

          <a class="navbar-item" href="/">
            <div class="image is-48x48"  >
              <img style="min-height: 48px" src="https://bulma.io/images/placeholders/256x256.png">
            </div>
            <span class="is-size-5 has-text-weight-semibold" style="padding-left: .75em" ><?php echo e(env('APP_NAME')); ?></span>
          </a>

          <a role="button" class="navbar-burger burger" style="height: initial" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
            <span aria-hidden="true"></span>
          </a>
        </div>

        <div class="navbar-menu">
          <div class="navbar-start">

            <?php if(auth()->guard()->check()): ?>
            <?php $__env->startSection('navbar_menu'); ?>

            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                  <?php echo e(__('admin.usuarios')); ?>

                </a>
                <div class="navbar-dropdown">
                  <a class="navbar-item" href="/admin/usuarios">
                    <?php echo e(__('admin.administrar_usuarios')); ?>

                  </a>
                  <a class="navbar-item" href="/admin/usuarios/create">
                    <?php echo e(__('admin.nuevo')); ?>

                  </a>
                </div>
            </div>

            
            <?php echo $__env->yieldSection(); ?>
            <?php endif; ?>

          </div>

          <div class="navbar-end">
            <div class="navbar-item has-dropdown is-hoverable" dusk="selector-idioma" >
              <a class="navbar-link is-arrowless" href="/idioma/es_AR"><?php echo e(config('app.locale')); ?></a>
              <div class="navbar-dropdown">
              <?php $__currentLoopData = config('app.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a class="navbar-item" href="/idioma/<?php echo e($locale); ?>"><?php echo e($locale); ?></a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              </div>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <div class="navbar-item has-dropdown is-hoverable">
                <a class="navbar-link">
                  <div style="display: flex; align-items: center">
                    <div style="padding-right: .75em">
                      <div class="image is-48x48">
                        <img class="is-rounded" style="min-height: 48px" src="https://bulma.io/images/placeholders/128x128.png">
                      </div>
                    </div>
                    <div class="">
                      <div class="activador_media-content-usuario has-text-weight-semibold">
                        <?php echo e(auth()->user()->nombreCompleto); ?>

                      </div>
                    </div>
                  </div>

                </a>
                <div class="navbar-dropdown">
                  <?php if(auth()->guard()->guest()): ?>
                  <a class="navbar-item" href="/login" >
                      <?php echo e(__(('frontend.login'))); ?>

                  </a>
                  <?php endif; ?>
                  <?php if(auth()->guard()->check()): ?>
                  <a class="navbar-item" href="/notificaciones" >
                      <?php echo e(__(('frontend.mis_notificaciones'))); ?>

                  </a>
                  <a class="navbar-item" href="/inscripciones" >
                      <?php echo e(__(('frontend.mis_inscripciones'))); ?>

                  </a>
                  <a class="navbar-item" href="" >
                      <?php echo e(__(('frontend.perfil'))); ?>

                  </a>
                  <hr class="navbar-divider">
                  <a class="navbar-item" href="/logout" 
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();" >
                      <form id="logout-form" method="POST" action="/logout" style="display:none"><?php echo e(csrf_field()); ?></form>
                      <?php echo e(__(('frontend.logout'))); ?>

                  </a>
                  <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
            <div class="navbar-item">
              <a href="/login" class="button is-inverted has-text-weight-semibold has-text-primary" ><?php echo e(__('frontend.ingresar')); ?></a>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </nav>
    <?php echo $__env->yieldSection(); ?>

    <div class="container" style="flex-grow: 1;">
    <?php echo $__env->yieldContent("content"); ?>
    </div>

    <footer class="footer has-background-grey-lighter">
      <div class="has-text-centered">
        <p><strong>Alumni</strong> by <a href="http://www.ensenaporargentina.org">Enseña por Argentina</a></p>
        <p>
          <span class="icon is-medium"><i class="fab fa-lg fa-twitter-square"></i></span>
          <span class="icon is-medium"><i class="fab fa-lg fa-facebook"></i></span>
          <span class="icon is-medium"><i class="fab fa-lg fa-instagram"></i></span>
        </p>
        <p>Accedé al código en <a href="https://github.com/agustempo/activador"><i class="fab fa-github-alt"></i> Github</a></p>
      </div>
    </footer>

  </body>
</html>
<?php /* /home/sugar/TEC/activador/resources/views/layouts/home.blade.php */ ?>