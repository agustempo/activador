	
<?php $__env->startSection('title'); ?>
<?php echo e(ucfirst($actividad->nombre)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">

	<h4 class="title is-4"><?php echo e(ucfirst($actividad->nombre)); ?></h4>
	
	<?php echo $__env->make("admin.actividades.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('contenido-actividad'); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/actividad.blade.php */ ?>