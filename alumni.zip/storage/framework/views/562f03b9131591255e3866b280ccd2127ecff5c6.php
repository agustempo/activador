<?php $__env->startSection('content'); ?>
<div class="section">
    <div class="columns">
        <div class="column is-4 is-offset-4">
            <div class="box">
                <div class="title is-4"><?php echo e(__('auth.login')); ?></div>

                <div class="" >
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="field">
                            <label for="email" class="label"><?php echo e(__('auth.email')); ?></label>

                            <div class="control has-icons-left has-icons-right">
                                <input id="email" type="email" class="input <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                                <span class="icon is-small is-left">
                                  <i class="fas fa-envelope"></i>
                                </span>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field">
                            <label for="password" class="label"><?php echo e(__('auth.password')); ?></label>

                            <div class="control has-icons-left has-icons-right">
                                <input id="password" type="password" class="input <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                                <span class="icon is-small is-left">
                                  <i class="fas fa-lock"></i>
                                </span>

                                <?php if($errors->has('password')): ?>
                                    <span class="notification is-danger" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <label class="checkbox" for="remember">
                                        <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <?php echo e(__('auth.remember_me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="">
                            <div class="buttons">
                                <button type="submit" class="button is-primary">
                                    <?php echo e(__('auth.login')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('auth.forgot_password')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/auth/login.blade.php */ ?>