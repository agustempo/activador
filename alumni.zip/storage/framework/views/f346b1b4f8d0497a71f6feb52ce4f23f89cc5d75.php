<?php $__env->startSection('title'); ?>
<?php echo e(__('admin.listado_de')); ?> <?php echo e(__('admin.usuarios')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
	<div class="content">
		
		<h3><?php echo e(__('admin.listado_de')); ?> <?php echo e(__('admin.usuarios')); ?></h3>
		<p><a href="/admin/usuarios/create" class="button is-link" ><?php echo e(__('admin.nuevo')); ?></a></p>

		<table class="table">
		  <thead>
		    <tr>
		      <th>Nombre</th>
		      <th>Apellido</th>
		      <th><abbr title="Telefono">Tel</abbr></th>
		      <th><abbr title="Correo Electronico">Mail</abbr></th>
		    </tr>
		  </thead>
		  <tbody>
		  		<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><a href="/admin/usuarios/<?php echo e($usuario->id); ?>"><?php echo e($usuario->nombre); ?></a></td>
						<td><?php echo e($usuario->apellido); ?></td>
						<td>11545245</td>
						<td><?php echo e($usuario->email); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  </tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/usuarios/index.blade.php */ ?>