<?php $__env->startSection('content'); ?>
<div class="section">
    
    <?php if(session('mensaje')): ?>
        <div class="notification is-success"><?php echo e(__('frontend.'.session('mensaje'))); ?></div>
    <?php endif; ?>

    <div class="columns">
        <div class="column is-half is-offset-one-quarter">

            <h1 class="title is-4" ><?php echo e(__('frontend.evaluar')); ?>: <?php echo e($actividad->nombre); ?></h1>

            <div class="content">
                <p><?php echo e(__('frontend.evaluar_bajada')); ?></p>
            </div>

            <form id="form-evaluar" method="POST" action="/actividades/<?php echo e($actividad->id); ?>/evaluaciones/<?php echo e(optional($evaluacion)->id); ?>">
                <?php echo csrf_field(); ?>
                <?php if($evaluacion): ?>
                   <?php echo e(method_field('PATCH')); ?>

                <?php endif; ?>
                <div class="field">
                    <label class="label"><?php echo e(__(('frontend.puntaje'))); ?></label>
                    <div class="control has-icons-left">
                        <div class="select">
                          <select name="puntaje">
                            <option value="" disabled selected ><?php echo e(__(('frontend.placeholder_puntaje'))); ?></option>
                            <?php for($i = 1; $i <= 10; $i++): ?>
                                <?php if(old('puntaje') == $i or optional($evaluacion)->puntaje == $i): ?>
                                    <option value="<?php echo e($i); ?>" selected ><?php echo e($i); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endif; ?>
                            <?php endfor; ?>
                          </select>
                        </div>
                        <span class="icon is-left">
                            <i class="fas fa-ruler"></i>
                        </span>
                    </div>
                    <p class="help"><?php echo e(__(('frontend.ayuda_puntaje'))); ?></p>
                </div>

                <div class="field">
                    <label class="label"><?php echo e(__(('frontend.comentario'))); ?></label>
                    <div class="control">
                        <textarea 
                            class="textarea" 
                            name="comentario" 
                            placeholder="<?php echo e(__(('frontend.placeholder_comentario'))); ?>"
                            ><?php echo e(old('comentario', optional($evaluacion)->comentario)); ?></textarea>
                    </div>
                    <p class="help"><?php echo e(__(('frontend.ayuda_comentario'))); ?></p>
                </div>

                <div class="field">
                    <div class="buttons is-right">
                        <button onclick="event.preventDefault();document.getElementById('form-evaluar').submit();" 
                            class="button is-link">
                            <?php if($actividad->evaluaciones()->exists()): ?>
                                <?php echo e(__('frontend.editar')); ?>

                            <?php else: ?>
                                <?php echo e(__('frontend.evaluar')); ?>

                            <?php endif; ?>
                        </button>
                    </div>
                </div>  
            </form>

            <?php if($actividad->evaluaciones()->exists()): ?>
            <form method="POST" action="/actividades/<?php echo e($actividad->id); ?>/evaluaciones/<?php echo e(optional($evaluacion)->id); ?>">
                <?php echo csrf_field(); ?>
                <?php if($actividad->evaluaciones()->exists()): ?>
                   <?php echo e(method_field('DELETE')); ?>

                <?php endif; ?>
                <div class="field">
                    <div class="buttons is-right">
                        <button class="button is-danger"><?php echo e(__('frontend.eliminar')); ?></button>
                    </div>
                </div>
            </form>
            <?php endif; ?>

            <br>

            <?php if($errors->any()): ?>
            <div class="notification is-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

        </div>  
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/evaluaciones.blade.php */ ?>