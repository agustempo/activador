<?php $__env->startSection("contenido-actividad"); ?>

<form method="POST" action="/admin/actividades/<?php echo e($actividad->id); ?>" >
	
	<?php echo e(method_field('PATCH')); ?>


	<?php echo $__env->make("admin.actividades.form", [ 'deshabilitado' => false ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<input type="submit" class="button is-link" value="<?php echo e(__(('admin.editar'))); ?>" ></input>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.actividades.actividad", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/edit.blade.php */ ?>