<?php $__env->startSection('title'); ?>
Nueva actividad
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection("content"); ?>
<div class="section">

	<div class="columns">

		<div class="column is-8 is-offset-2">
		
			<h1 class="title is-4" ><?php echo e(__(('admin.nueva'))); ?> <?php echo e(__(('admin.actividad'))); ?></h1>
			
			<form method="POST" action="/admin/actividades/" >

				<?php echo $__env->make("admin.actividades.form", [ 'actividad' => new App\Actividad, 'textoBoton' => __(('admin.nueva')), 'deshabilitado' => false ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				<input type="submit" class="button is-primary" dusk="crear" value="<?php echo e(__(('admin.nueva'))); ?>" ></input>
				
			</form>

		</div>
	</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/create.blade.php */ ?>