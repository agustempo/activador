<?php $__env->startSection('title'); ?>
<?php echo e(__('admin.detalle_de')); ?> <?php echo e(__('admin.usuarios')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="section">
	<div class="content">
		<form method="POST" action="" >
			<?php echo $__env->make("admin.usuarios.form", [ 'deshabilitado' => true ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</form>

		<br/>

		<div class="field is-grouped" >
			<p class="control">
				<a class="button" href="/admin/usuarios/<?php echo e($usuario->id); ?>/edit" > <?php echo e(__(('admin.editar'))); ?></a>
			</p>
			<form id="form-eliminar" method="POST" action="/admin/usuarios/<?php echo e($usuario->id); ?>" style="display:none" >
				<?php echo e(method_field('DELETE')); ?>

				<?php echo e(csrf_field()); ?>

			</form>
			<p class="control" >
				<a class="button is-danger" onclick="document.getElementById('form-eliminar').submit()" > <?php echo e(__(('admin.eliminar'))); ?></a>
			</p>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/usuarios/show.blade.php */ ?>