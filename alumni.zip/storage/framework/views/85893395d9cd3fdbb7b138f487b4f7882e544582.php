<?php $__env->startSection("contenido-actividad"); ?>

	<form method="POST" action="/admin/actividades/<?php echo e($actividad->id); ?>/inscripciones" >
		
		<?php echo e(csrf_field()); ?>


		<div class="field is-flex-desktop">
			<div class="control">
				<div class="select">
					<select name="id_usuario">
					<option value="" disabled selected ><?php echo e(__(('admin.seleccionar_usuario'))); ?></option>
					<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option  value="<?php echo e($usuario->id); ?>" ><?php echo e($usuario->email); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="control">
				<input type="submit" class="button is-link" value="<?php echo e(__(('admin.inscribir'))); ?>" ></input>
			</div>
		</div>

		<br/>

		<?php if(session('mensajes')): ?>
			<div class="notification is-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>

	</form>

	<div class="content" >
		<table class="table">
			<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $actividad->inscriptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscripto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<tr><td><?php echo e($inscripto->usuario->nombre); ?> <?php echo e($inscripto->usuario->apellido); ?></td>
						<td>
						<div class="buttons is-right are-small">

							<form id="form-presente-<?php echo e($inscripto->id); ?>" method="POST" action="<?php echo e($inscripto->path_admin()); ?>" >
								<?php echo e(method_field('PATCH')); ?>

								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="presente" value="<?php echo e($inscripto->presente === 1 ? 0 : 1); ?>" ></input>
									<a href="javascript:{}" class="button" onclick="document.getElementById('form-presente-<?php echo e($inscripto->id); ?>').submit()" >
										<span class="is-hidden-touch" ><?php echo e(__(('admin.presente'))); ?></span>
										<span class="icon" >
											<i class="fas <?php echo e($inscripto->presente === 1 ? __(('fa-toggle-on')):__(('fa-toggle-off'))); ?>" ></i>
										</span>
									</a>
							</form>
							
							<form id="form-confirma-<?php echo e($inscripto->id); ?>" method="POST" action="<?php echo e($inscripto->path_admin()); ?>" >
								<?php echo e(method_field('PATCH')); ?>

								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="confirma" value="<?php echo e($inscripto->confirma === 1 ? 0 : 1); ?>" ></input>
									<a href="javascript:{}" class="button" onclick="document.getElementById('form-confirma-<?php echo e($inscripto->id); ?>').submit()" >
										<span class="is-hidden-touch" ><?php echo e(__(('admin.confirmar'))); ?></span>
										<span class="icon" >
											<i class="fas <?php echo e($inscripto->confirma === 1 ? __(('fa-toggle-on')):__(('fa-toggle-off'))); ?>" ></i>
										</span>
									</a>
							</form>

							<form id="form-eliminar-<?php echo e($inscripto->id); ?>" method="POST" action="<?php echo e($inscripto->path_admin()); ?>" >
								<?php echo e(method_field('DELETE')); ?>

								<?php echo e(csrf_field()); ?>

								<a href="javascript:{}" class="button is-danger" onclick="document.getElementById('form-eliminar-<?php echo e($inscripto->id); ?>').submit()" >
									<span class="is-hidden-touch" ><?php echo e(__(('admin.eliminar'))); ?></span>
									<span class="icon" >
										<i class="fas fa-trash" ></i>
									</span>
								</a>
							</form>

						</div>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr><td><?php echo e(__(('admin.no_hay_inscriptos'))); ?></td></tr>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.actividades.actividad", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/inscriptos.blade.php */ ?>