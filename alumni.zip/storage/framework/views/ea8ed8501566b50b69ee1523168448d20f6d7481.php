<?php $__env->startSection("contenido-actividad"); ?>
<div>
	<form class="form" method="POST" action="<?php echo e($actividad->path_admin() . '/invitaciones'); ?>" >
		<?php echo e(csrf_field()); ?>

		<div class="field is-flex-desktop">
			<div class="control">
				<div class="select">
					<select name="id_usuario">
					<option value="" disabled selected ><?php echo e(__(('admin.seleccionar_usuario'))); ?></option>
					<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option  value="<?php echo e($usuario->id); ?>" ><?php echo e($usuario->email); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
			<div class="control">
				<input class="button is-link" type="submit" value="<?php echo e(__(('admin.invitar'))); ?>" />
			</div>
		</div>
	</form>

	<?php if($errors->any()): ?>
	<div class="notification is-danger">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
	<?php endif; ?>
</div>

<div class="content" >
	<ul>
		<?php $__empty_1 = true; $__currentLoopData = $actividad->miembros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $miembro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li>
				<?php echo e($miembro->nombre); ?>

			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li><?php echo e(__(('admin.no_hay_miembros'))); ?></li>
		<?php endif; ?>
	</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.actividades.actividad", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/miembros.blade.php */ ?>