
		<?php echo e(csrf_field()); ?>


		<div class="field">
			<label class="label"><?php echo e(__(('admin.nombre'))); ?></label>
	  		<div class="control">
				<input class="input <?php echo e($errors->has('nombre') ? 'is-danger' : ''); ?>" type="text" name="nombre" value="<?php echo e(($actividad->nombre)?$actividad->nombre:old('nombre')); ?>"  <?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>
		<div class="field">
			<label class="label"><?php echo e(__(('admin.descripcion'))); ?></label>
	  		<div class="control">
				<textarea 
					class="textarea <?php echo e($errors->has('descripcion') ? 'is-danger' : ''); ?>" 
					name="descripcion" <?php echo e(($deshabilitado)?"disabled":""); ?>><?php echo e(($actividad->descripcion)?$actividad->descripcion:old('descripcion')); ?></textarea>
			</div>
		</div>
		<div class="field">
			<label class="label"><?php echo e(__(('admin.inicio'))); ?></label>
	  		<div class="control">
				<input 
					class="input <?php echo e($errors->has('inicio') ? 'is-danger' : ''); ?>" 
					type="datetime-local" 
					name="inicio" 
					value="<?php echo e(($actividad->inicio)?$actividad->finDatetimeLocal:old('inicio')); ?>" 
					<?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>

		<div class="field">
			<label class="label"><?php echo e(__(('admin.fin'))); ?></label>
	  		<div class="control">
				<input 
					class="input <?php echo e($errors->has('fin') ? 'is-danger' : ''); ?>" 
					type="datetime-local" 
					name="fin" 
					value="<?php echo e(($actividad->fin)?$actividad->finDatetimeLocal:old('fin')); ?>" 
					<?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>

		<div class="field">
			<label class="label"><?php echo e(__(('admin.lugar'))); ?></label>
	  		<div class="control">
				<input 
				class="input <?php echo e($errors->has('lugar') ? 'is-danger' : ''); ?>" 
				type="text" 
				name="lugar" 
				value="<?php echo e(($actividad->lugar)?$actividad->lugar:old('lugar')); ?>" 
				<?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>

		<?php if($errors->any()): ?>
		<div class="notification is-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/form.blade.php */ ?>