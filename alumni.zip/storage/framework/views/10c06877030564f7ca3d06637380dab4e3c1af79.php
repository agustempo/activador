<?php $__env->startSection('title'); ?>
<?php echo e(__('admin.listado_de')); ?> <?php echo e(__('admin.actividades')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="section">
	<div class="content">
		<p><a href="/admin/actividades/create" class="button is-primary" ><?php echo e(__('admin.nueva')); ?></a></p>

		<h4><?php echo e(__('admin.listado_de')); ?> <?php echo e(__('admin.actividades')); ?></h4>
		<ul>
		<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<li><a href="/admin/actividades/<?php echo e($actividad->id); ?>"><?php echo e($actividad->nombre); ?></a></li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/index.blade.php */ ?>