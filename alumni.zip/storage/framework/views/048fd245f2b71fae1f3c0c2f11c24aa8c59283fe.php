<?php $__env->startSection('title'); ?>
<?php echo e(__('frontend.mis_notificaciones')); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="section content">
	<h3 class="title is-4"><?php echo e(__('frontend.mis_notificaciones')); ?></h3>
	<ul>
	<?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	<li>
		<?php echo $__env->make("notificaciones." . class_basename($notificacion->type), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   	</li>
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   		<li><?php echo e(__('frontend.no_hay_notificaciones')); ?></li>
	<?php endif; ?>
	</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/notificaciones.blade.php */ ?>