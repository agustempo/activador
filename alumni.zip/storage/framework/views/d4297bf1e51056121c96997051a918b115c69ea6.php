<?php echo e(__('notificaciones.te_inscribiste')); ?>

<a href="/actividades/<?php echo e($notificacion->data['id']); ?>"><?php echo e($notificacion->data["nombre"]); ?></a>
<?php echo e(__('notificaciones.accede_a_inscripciones')); ?>

<a href="/inscripciones"><?php echo e(__('notificaciones.aca')); ?></a>
<span class="has-text-grey-light" ><?php echo e($notificacion->updated_at->diffForHumans()); ?></span>
<?php /* /home/sugar/TEC/activador/resources/views/notificaciones/InscripcionRealizada.blade.php */ ?>