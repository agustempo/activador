<span><b><?php echo e($auditoria->usuario->nombreCompleto); ?></b></span> 
<span><?php echo e(__(('admin.creo_actividad'))); ?></span> 
<span class="has-text-grey-light" ><?php echo e($auditoria->updated_at->diffForHumans()); ?></span>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/auditoria/actividad_created.blade.php */ ?>