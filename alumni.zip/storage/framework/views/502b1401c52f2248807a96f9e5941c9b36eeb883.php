<?php echo e(__('prueba.prueba_idioma')); ?>
<?php /* /home/sugar/TEC/activador/resources/views/idioma_prueba.blade.php */ ?>