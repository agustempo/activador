<?php $__env->startSection("contenido-actividad"); ?>

<form method="POST" action="" >

	<?php echo $__env->make("admin.actividades.form", [ 'deshabilitado' => true ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>

<br/>

<div class="field is-grouped" >
	<p class="control">
		<a class="button" href="/admin/actividades/<?php echo e($actividad->id); ?>/edit" > <?php echo e(__(('admin.editar'))); ?></a>
	</p>
	<form id="form-eliminar" method="POST" action="/admin/actividades/<?php echo e($actividad->id); ?>" style="display:none" >
			<?php echo e(method_field('DELETE')); ?>

			<?php echo e(csrf_field()); ?>

	</form>
	<p class="control" >
		<a class="button is-danger" onclick="document.getElementById('form-eliminar').submit()" > <?php echo e(__(('admin.eliminar'))); ?></a>
	</p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.actividades.actividad", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/show.blade.php */ ?>