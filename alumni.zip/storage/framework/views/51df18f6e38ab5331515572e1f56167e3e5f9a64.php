<div class="tabs is-toggle">
  <ul>
    <li><a href="<?php echo e($actividad->path_admin()); ?>" ><?php echo e(__(('admin.general'))); ?></a></li>
    <li><a href="<?php echo e($actividad->path_admin() . '/inscripciones'); ?>" ><?php echo e(__(('admin.inscripciones'))); ?> </a></li>
    <li><a href="<?php echo e($actividad->path_admin() . '/evaluaciones'); ?>" ><?php echo e(__(('admin.evaluaciones'))); ?> </a></li>
    <li><a href="<?php echo e($actividad->path_admin() . '/invitaciones'); ?>" ><?php echo e(__(('admin.invitaciones'))); ?> </a></li>
    <li><a href="<?php echo e($actividad->path_admin() . '/auditoria'); ?>" ><?php echo e(__(('admin.auditoria'))); ?> </a></li>
    <li><a><?php echo e(__(('admin.puntos'))); ?> </a></li>
    <li><a><?php echo e(__(('admin.grupos'))); ?> </a></li>
  </ul>
</div>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/menu.blade.php */ ?>