<span><b><?php echo e($auditoria->usuario->nombreCompleto); ?></b></span>
<span><?php echo e(__(('admin.edito_actividad'))); ?></span> 
<span>
	{
	<?php $__currentLoopData = $auditoria->cambios['antes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <b><?php echo e($atributo); ?></b>: <?php echo e($valor); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php $__currentLoopData = $auditoria->cambios['despues']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atributo => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <b><?php echo e($atributo); ?></b>: <?php echo e($valor); ?>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	}
</span> 
<span class="has-text-grey-light" ><?php echo e($auditoria->updated_at->diffForHumans()); ?></span>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/auditoria/actividad_updated.blade.php */ ?>