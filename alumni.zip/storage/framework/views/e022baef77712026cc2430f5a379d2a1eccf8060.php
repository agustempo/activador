<?php $__env->startSection('title'); ?>
<?php echo e(__('frontend.mis_inscripciones')); ?>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
<div class="section content">
	<h3 class="title is-4"><?php echo e(__('frontend.mis_inscripciones')); ?></h3>
	<ul>
	<?php $__empty_1 = true; $__currentLoopData = $inscripciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscripcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<li><a href="/actividades/<?php echo e($inscripcion->actividad->id); ?>"> <?php echo e($inscripcion->actividad->nombre); ?></a>
			<form 
				id="form-desinscribirme" 
				method="POST" 
				action="/inscripciones/<?php echo e($inscripcion->id); ?>"
				style="display:none" >
		        <?php echo e(csrf_field()); ?>

		        <?php echo e(method_field('delete')); ?>

		    </form>
		    <a onclick="event.preventDefault();document.getElementById('form-desinscribirme').submit();" 
		    class="button is-danger"><?php echo e(__('frontend.desinscribirme')); ?></a>
		    <a href="<?php echo e($inscripcion->actividad->path_publico() . '/evaluaciones'); ?>" class="button is-info"><?php echo e(__('frontend.evaluar')); ?></a>
	   	</li>
	   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
	   	<li><?php echo e(__('frontend.no_hay_inscripciones')); ?></li>
	<?php endif; ?>
	</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/inscripciones.blade.php */ ?>