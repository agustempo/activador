<?php $__env->startSection('title'); ?>
Nuevo Usuario
<?php $__env->stopSection(); ?>
	
<?php $__env->startSection("content"); ?>
<div class="section">
	
	<h1 class="title is-4" ><?php echo e(__(('admin.nueva'))); ?> <?php echo e(__(('admin.usuario'))); ?></h1>
	
	<form method="POST" action="/admin/usuarios/" >

		<?php echo $__env->make("admin.usuarios.form", [ 'usuario' => new App\Usuario, 'textoBoton' => __(('admin.nueva')), 'deshabilitado' => false ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<input type="submit" class="button is-link" dusk="crear" value="<?php echo e(__(('admin.nueva'))); ?>" ></input>
		
	</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/usuarios/create.blade.php */ ?>