<?php $__env->startSection('content'); ?>
<div class="section">
    
    <h1 class="title" ><?php echo e($actividad->nombre); ?></h1>
    
    <div class="columns" style="flex-direction: column">
        <div class="column">
            <div class="level" style="justify-content: initial;">
                <div class="level-right" style="margin-right: .5em" >
                    <i class="icon fas fa-calendar-alt" style="margin-right: .5em;"></i> <?php echo e($actividad->cuando); ?> 

                    (<?php echo e($actividad->duracion); ?>)
                </div>
                <div class="level-left" >
                    <i class="icon fas fa-map-marker-alt" style="margin-right: .5em;"></i> <?php echo e($actividad->lugar); ?>

                </div>
            </div>
        </div>
        <div class="column">
            <div class="box" style="display: flex; align-items: center; width: fit-content;">
                <div class="image is-48x48" style="margin-right: .75em">
                    <img class="is-rounded" style="min-height: 48px;" src="https://bulma.io/images/placeholders/128x128.png">
                </div>
                <p class="title is-6"><?php echo e($actividad->creador->nombre); ?></p>
            </div>
        </div>
    </div>
</div>
<div class="section">
    <p class="content">
        <?php echo e($actividad->descripcion); ?>

    </p>
</div>
<div class="section">
    <div class="buttons is-right">
        <div class="button"><?php echo e(__('frontend.compartir')); ?></div>
        <?php if(Auth::check() && $actividad->esta_inscripto(auth()->user())): ?>
            <a class="button is-link is-outlined"><?php echo e(__('frontend.inscripto')); ?></a>
        <?php else: ?>
            <form id="form-inscribirme" method="POST" action="/actividades/<?php echo e($actividad->id); ?>/inscripciones" >
            <?php echo e(csrf_field()); ?>

            </form>
            <a onclick="event.preventDefault();document.getElementById('form-inscribirme').submit();" 
            class="button is-link"><?php echo e(__('frontend.inscribirme')); ?></a>
        <?php endif; ?>
    </div>

    <?php if($errors->any()): ?>
        <div class="notification is-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('mensaje')): ?>
        <div class="notification is-success"><?php echo e(__('frontend.'.session('mensaje'))); ?></div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/actividad.blade.php */ ?>