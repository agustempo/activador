<?php $__env->startSection('title'); ?>
<?php echo e(__('admin.detalle_de')); ?> <?php echo e(__('admin.usuarios')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="section">
	<div class="content">

		<form method="POST" action="/admin/usuarios/<?php echo e($usuario->id); ?>" >
			<?php echo e(method_field('PATCH')); ?>

			<?php echo $__env->make("admin.usuarios.form", [ 'deshabilitado' => false ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<input type="submit" class="button is-link" value="<?php echo e(__(('admin.guardar'))); ?>" ></input>
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/usuarios/edit.blade.php */ ?>