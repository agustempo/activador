<span><b><?php echo e($auditoria->usuario->nombreCompleto); ?></b></span>
<?php if($auditoria->objeto && $auditoria->usuario == $auditoria->objeto->usuario): ?>
<span><?php echo e(__('admin.se_inscribio')); ?></span> 
<?php else: ?>
<span><?php echo e(__('admin.creo_inscripcion')); ?></span> 
<span> 
	<?php if($auditoria->objeto): ?>
		<?php echo e($auditoria->objeto->usuario->nombreCompleto); ?>

	<?php endif; ?>
</span> 
<?php endif; ?>

<span class="has-text-grey-light" ><?php echo e($auditoria->updated_at->diffForHumans()); ?></span>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/auditoria/inscripcion_created.blade.php */ ?>