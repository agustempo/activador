<?php $__env->startSection("contenido-actividad"); ?>
<div class="content" >
	<ul>
		<?php $__empty_1 = true; $__currentLoopData = $actividad->evaluaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li>
				<b><?php echo e($evaluacion->usuario->nombreCompleto); ?></b>
				<span><?php echo e($evaluacion->puntaje); ?></span>
				<span><?php echo e($evaluacion->comentario); ?></span>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li><?php echo e(__('admin.no_hay_evaluaciones')); ?></li>
		<?php endif; ?>
	</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.actividades.actividad", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/actividades/evaluaciones.blade.php */ ?>