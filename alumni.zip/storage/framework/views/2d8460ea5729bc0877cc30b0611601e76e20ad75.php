
		<?php echo e(csrf_field()); ?>


		<div class="field">
			<label class="label"><?php echo e(__(('admin.nombre'))); ?></label>
	  		<div class="control">
				<input class="input <?php echo e($errors->has('nombre') ? 'is-danger' : ''); ?>" 
				type="text" name="nombre" value="<?php echo e(($usuario->nombre)?$usuario->nombre:old('nombre')); ?>"  
				<?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>
		<div class="field">
			<label class="label"><?php echo e(__(('admin.apellido'))); ?></label>
	  		<div class="control">
				<input 
					class="input <?php echo e($errors->has('apellido') ? 'is-danger' : ''); ?>" 
					name="apellido" <?php echo e(($deshabilitado)?"disabled":""); ?> value="<?php echo e(($usuario->apellido)?$usuario->apellido:old('apellido')); ?>"></input>
			</div>
		</div>
		
		<div class="field">
			<label class="label"><?php echo e(__(('admin.email'))); ?></label>
	  		<div class="control">
				<input 
				class="input <?php echo e($errors->has('email') ? 'is-danger' : ''); ?>" 
				type="text" 
				name="email" 
				value="<?php echo e(($usuario->email)?$usuario->email:old('email')); ?>" 
				<?php echo e(($deshabilitado)?"disabled":""); ?>></input>
			</div>
		</div>

		<div class="field">
			<label class="label"><?php echo e(__(('admin.password'))); ?></label>
	  		<div class="control">
				<input 
					type="password" 
					class="input <?php echo e($errors->has('password') ? 'is-danger' : ''); ?>" 
					name="password" <?php echo e(($deshabilitado)?"disabled":""); ?> value="<?php echo e(($usuario->password)?$usuario->password:old('password')); ?>"></input>
			</div>
		</div>

		<?php if($errors->any()): ?>
		<div class="notification is-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
<?php /* /home/sugar/TEC/activador/resources/views/admin/usuarios/form.blade.php */ ?>