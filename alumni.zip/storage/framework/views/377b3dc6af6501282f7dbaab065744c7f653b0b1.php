<?php $__env->startSection('content'); ?>
<section class="hero is-light" style="height: 212px">
    <div class="hero-body" style="display: flex; align-items: center; justify-content: center;">
        <h1 class="title" ><?php echo e(__('frontend.explora_actividades')); ?></h1>
    </div>
</section>

<div class="section">
    <div class="columns is-multiline">
        <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="column is-one-quarter">
            
            <div class="card">

                <header class="card-header">
                    <div class="card-header-title">
                        <p class="title is-4"><?php echo e($actividad->nombre); ?></p>
                    </div>
                </header>

                <div class="card-content">
                    <div class="content">
                        <span class="tag is-info" >#Tipo</span>
                        <div style="margin: .75rem 0">
                            <span class="icon">
                                <i class="fas fa-calendar-minus" ></i><time datetime="2016-1-1"></time>
                            </span>
                            <span><?php echo e($actividad->cuando); ?></span>
                        </div>
                        <div>
                            <span class="icon">
                                <i class="fas fa-map-marker-alt" ></i>
                            </span>
                            <span><?php echo e($actividad->lugar); ?></span>
                        </div>

                        <div class="media" style="align-items: center; margin: .75rem 0;">
                          <div class="media-left">
                            <div class="image is-48x48">
                              <img class="is-rounded" src="https://bulma.io/images/placeholders/96x96.png" alt="Placeholder image">
                            </div>
                          </div>
                          <div class="media-content">
                            <p class=""><?php echo e($actividad->creador->nombre); ?></p>
                          </div>
                        </div> 

                        <p><?php echo e($actividad->resumen); ?></p>
                    </div>
                </div>

                <footer class="card-footer">
                    <?php if(Auth::check() && $actividad->esta_inscripto(auth()->user())): ?>
                        <a href="/actividades/<?php echo e($actividad->id); ?>" class="card-footer-item"><?php echo e(__('frontend.inscripto')); ?></a>
                    <?php else: ?>
                        <a href="/actividades/<?php echo e($actividad->id); ?>" class="card-footer-item"><?php echo e(__('frontend.ver')); ?></a>
                    <?php endif; ?>
                </footer>
                
            </div>
        
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/sugar/TEC/activador/resources/views/actividades.blade.php */ ?>